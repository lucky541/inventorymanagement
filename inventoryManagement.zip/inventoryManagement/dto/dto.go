package dto

import (
	"errors"
	"github.com/lucky541/inventoryManagement/storage"
	"time"
)

type Price struct {
	Min int `json:"min"`
	Max int `json:"max"`
}

type ListProductsFilter struct {
	SupplierID int    `json:"supplierId"`
	Price      *Price `json:"price"`
}

type Product struct {
	ID            int64     `json:"id"`
	Name          string    `json:"name"`
	Supplier      *Supplier `json:"supplier"`
	Price         float64   `json:"price"`
	StockQuantity int       `json:"stockQuantity"`
	Images        []*Image  `json:"images"`
	CreatedAt     time.Time `json:"createdAt"`
	UpdatedAt     time.Time `json:"updatedAt"`
}

func (p *Product) ValidateCreateProductRequest() []string {
	errorsSlice := make([]string, 0)
	if p.Name == "" {
		errorsSlice = append(errorsSlice, errors.New("product name can not be empty").Error())
	}
	if p.Supplier == nil || p.Supplier.ID == 0 {
		errorsSlice = append(errorsSlice, errors.New("supplier can not be nil or id can not be '0'").Error())
	}
	if p.Price <= 0 {
		errorsSlice = append(errorsSlice, errors.New("price can not be less than or equal to zero").Error())
	}
	if p.StockQuantity < 0 {
		errorsSlice = append(errorsSlice, errors.New("stock quantity can not be less than zero").Error())
	}
	if len(p.Images) > 10 {
		errorsSlice = append(errorsSlice, errors.New("max 10 images are allowed").Error())
	}
	return errorsSlice
}

func (p *Product) ValidateUpdateProductRequest() []string {
	errorsSlice := make([]string, 0)
	if p.Supplier != nil && p.Supplier.ID == 0 {
		errorsSlice = append(errorsSlice, errors.New("supplier id can not be '0'").Error())
	}
	if p.Price < 0 {
		errorsSlice = append(errorsSlice, errors.New("price can not be less than or equal to zero").Error())
	}
	if p.StockQuantity < 0 {
		errorsSlice = append(errorsSlice, errors.New("stock quantity can not be less than zero").Error())
	}
	if len(p.Images) > 10 {
		errorsSlice = append(errorsSlice, errors.New("max 10 images are allowed").Error())
	}
	return errorsSlice
}

func (p *Product) ValidateAdjustmentRequest() []string {
	errorsSlice := make([]string, 0)
	if p.StockQuantity < 0 {
		errorsSlice = append(errorsSlice, errors.New("stock quantity can not be less than zero").Error())
	}
	return errorsSlice
}

type ListProduct struct {
	Products []*Product `json:"products"`
}

type Image struct {
	ID        int64  `json:"id"`
	Name      string `json:"name"`
	Data      []byte `json:"data"`
	CreatedAt time.Time
	UpdatedAt time.Time
}

type Supplier struct {
	ID          int64     `json:"id"`
	Name        string    `json:"name"`
	PhoneNumber string    `json:"phoneNumber"`
	CreatedAt   time.Time `json:"createdAt"`
	UpdatedAt   time.Time `json:"updatedAt"`
}

func (s *Supplier) ValidateSupplierRequest() []string {
	errorsSlice := make([]string, 0)
	if s.Name == "" {
		errorsSlice = append(errorsSlice, errors.New("product name can not be empty").Error())
	}
	if s.PhoneNumber == "" {
		errorsSlice = append(errorsSlice, errors.New("product name can not be empty").Error())
	}
	return errorsSlice
}

type ListSupplier struct {
	Supplier []*Supplier `json:"suppliers"`
}

func GetSupplierDtoFromEntity(modal *storage.Supplier) *Supplier {
	if modal == nil {
		return nil
	}
	return &Supplier{
		ID:          int64(modal.ID),
		Name:        modal.Name,
		PhoneNumber: modal.PhoneNumber,
		CreatedAt:   modal.CreatedAt,
		UpdatedAt:   modal.UpdatedAt,
	}
}

func getImagesDtoFromEntity(imagesEntity []*storage.Image) []*Image {
	if imagesEntity == nil {
		return nil
	}

	var imagesDto []*Image
	for _, modal := range imagesEntity {
		imagesDto = append(imagesDto, &Image{
			ID:        int64(modal.ID),
			Name:      modal.Name,
			Data:      modal.Data,
			CreatedAt: modal.CreatedAt,
			UpdatedAt: modal.UpdatedAt,
		})
	}
	return imagesDto
}

func GetProductDtoFromEntity(entity *storage.Product, supplier *storage.Supplier, images []*storage.Image) *Product {
	return &Product{
		ID:            int64(entity.ID),
		Name:          entity.Name,
		Supplier:      GetSupplierDtoFromEntity(supplier),
		Price:         entity.Price,
		StockQuantity: entity.StockQuantity,
		Images:        getImagesDtoFromEntity(images),
		CreatedAt:     entity.CreatedAt,
		UpdatedAt:     entity.UpdatedAt,
	}
}

type MessageResponse struct {
	Status  string
	Message string
}
