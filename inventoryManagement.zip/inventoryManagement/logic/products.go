package logic

import (
	"errors"
	"fmt"
	"github.com/lucky541/inventoryManagement/dto"
	"github.com/lucky541/inventoryManagement/server/config"
	"github.com/lucky541/inventoryManagement/storage"
	"github.com/samber/lo"
	"gorm.io/gorm"
	"time"
)

type inventoryManagementServiceImpl struct {
	appConfig *config.AppConfig
	db        *gorm.DB
}

func (impl *inventoryManagementServiceImpl) CreateProduct(req *dto.Product) (*dto.Product, error) {
	createdAt, updatedAt := time.Now(), time.Now()
	supplierDto, err := impl.GetSupplierById(req.Supplier.ID)
	if err != nil {
		return nil, err
	}

	productEntity, err := impl.createProduct(req, supplierDto, createdAt, updatedAt)
	if err != nil {
		return nil, err
	}

	imagesEntity, err := impl.createImages(req, productEntity, createdAt)
	if err != nil {
		return nil, err
	}

	resp := dto.GetProductDtoFromEntity(productEntity, nil, imagesEntity)
	resp.Supplier = supplierDto
	return resp, nil
}

func (impl *inventoryManagementServiceImpl) createImages(req *dto.Product, productEntity *storage.Product, createdAt time.Time) ([]*storage.Image, error) {
	if req.Images == nil {
		return nil, nil
	}
	imagesEntity := []*storage.Image{}
	for _, image := range req.Images {
		imageEntity := &storage.Image{
			Name:      image.Name,
			Data:      image.Data,
			ProductID: productEntity.ID,
			CreatedAt: createdAt,
			UpdatedAt: createdAt,
		}
		if err := storage.Dao.Create(imageEntity); err != nil {
			fmt.Println("unable to create image err = %v", err.Error())
			return nil, errors.New(fmt.Sprintf("unable to create images err = %v", err.Error()))
		}
		imagesEntity = append(imagesEntity, imageEntity)
	}
	return imagesEntity, nil
}

func (impl *inventoryManagementServiceImpl) createProduct(req *dto.Product, supplierDto *dto.Supplier, createdAt time.Time, updatedAt time.Time) (*storage.Product, error) {
	productEntity := &storage.Product{
		Name:          req.Name,
		SupplierID:    uint(supplierDto.ID),
		Price:         req.Price,
		StockQuantity: req.StockQuantity,
		CreatedAt:     createdAt,
		UpdatedAt:     updatedAt,
	}

	if err := storage.Dao.Create(productEntity); err != nil {
		fmt.Println("unable to create product err = %v", err.Error())
		return nil, errors.New(fmt.Sprintf("unable to create product err = %v", err.Error()))
	}
	return productEntity, nil
}

func (impl *inventoryManagementServiceImpl) UpdateProduct(req *dto.Product) (*dto.MessageResponse, error) {
	productEntity := &storage.Product{}
	if err := storage.Dao.Find(productEntity, map[string]interface{}{"id": req.ID}); err != nil {
		fmt.Println("unable to get product err = %v", err.Error())
		return nil, errors.New("product does not exist")
	}
	_, err := impl.updateProduct(req, productEntity)
	if err != nil {
		return nil, errors.New("failed to update product")
	}

	//var newImagesEntity []*storage.Image
	if req.Images != nil {
		err := impl.updateImages(req)
		if err != nil {
			return nil, errors.New("failed to update images")
		}
	}

	return &dto.MessageResponse{
		Status:  "success",
		Message: "updated product successfully",
	}, nil
}

func (impl *inventoryManagementServiceImpl) updateImages(req *dto.Product) error {
	var imagesEntity []*storage.Image
	if err := storage.Dao.Find(&imagesEntity, map[string]interface{}{"product_id": req.ID}); err != nil {
		fmt.Println("unable to get images err = %v", err.Error())
		return errors.New(fmt.Sprintf("unable to get images err = %v", err.Error()))
	}
	for _, imageEntity := range imagesEntity {
		for _, imageDto := range req.Images {
			if int64(imageEntity.ID) != imageDto.ID {
				continue
			}

			if err := storage.Dao.Update(&imageEntity, &storage.Image{
				ID:        imageEntity.ID,
				Name:      lo.Ternary(imageDto.Name != "", imageDto.Name, imageEntity.Name),
				Data:      lo.Ternary(imageDto.Data != nil, imageDto.Data, imageEntity.Data),
				ProductID: uint(req.ID),
				UpdatedAt: time.Now(),
			}); err != nil {
				fmt.Println("unable to update images err = %v", err.Error())
				return errors.New(fmt.Sprintf("unable to update images err = %v", err.Error()))
			}
		}
	}
	return nil
}

func (impl *inventoryManagementServiceImpl) updateProduct(req *dto.Product, productEntity *storage.Product) (*storage.Product, error) {
	updatedAt := time.Now()
	newProductEntity := &storage.Product{
		ID:            productEntity.ID,
		Name:          lo.Ternary(req.Name != "", req.Name, productEntity.Name),
		Price:         lo.Ternary(req.Price >= 0, req.Price, productEntity.Price),
		StockQuantity: lo.Ternary(req.StockQuantity >= 0, req.StockQuantity, productEntity.StockQuantity),
		UpdatedAt:     updatedAt,
	}
	if req.Supplier != nil {
		newProductEntity.SupplierID = uint(req.Supplier.ID)
	}
	if err := storage.Dao.Update(productEntity, newProductEntity); err != nil {
		fmt.Println("unable to update product err = %v", err.Error())
		return nil, errors.New(fmt.Sprintf("unable to update product err = %v", err.Error()))
	}
	return newProductEntity, nil
}
func (impl *inventoryManagementServiceImpl) GetProductById(productID int64) (*dto.Product, error) {
	productEntity := &storage.Product{}
	if err := storage.Dao.Find(productEntity, map[string]interface{}{"id": productID}); err != nil {
		fmt.Println("unable to get product err = %v", err.Error())
		return nil, errors.New(fmt.Sprintf("unable to get product err = %v", err.Error()))
	}
	supplierEntity := &storage.Supplier{}
	if err := storage.Dao.Find(supplierEntity, map[string]interface{}{"id": productEntity.SupplierID}); err != nil {
		fmt.Println("unable to get supplier err = %v", err.Error())
		return nil, errors.New(fmt.Sprintf("unable to get suppliers err = %v", err.Error()))
	}

	var imagesEntity []*storage.Image
	if err := storage.Dao.Find(&imagesEntity, map[string]interface{}{"product_id": productID}); err != nil {
		fmt.Println("unable to get images err = %v", err.Error())
		return nil, errors.New(fmt.Sprintf("unable to get images err = %v", err.Error()))
	}
	return dto.GetProductDtoFromEntity(productEntity, supplierEntity, imagesEntity), nil
}

func (impl *inventoryManagementServiceImpl) GetProducts(req *dto.ListProductsFilter) (*dto.ListProduct, error) {
	products := []*dto.Product{}
	var productEntities []*storage.Product
	productCondition := make(map[string]string)
	query := impl.db.Model(&storage.Product{})
	if req.SupplierID != 0 {
		query = query.Where("supplier_id = ?", req.SupplierID)
	}
	if req.Price != nil {
		if req.Price.Max != 0 {
			query = query.Where("price < ?", req.Price.Max)
		}
		if req.Price.Min != 0 {
			query = query.Where("price > ?", req.Price.Min)
		}
	}
	if err := query.Find(&productEntities, productCondition).Error; err != nil {
		fmt.Println("unable to get product err = %v", err.Error())
		return nil, err
	}
	for _, productEntity := range productEntities {
		supplierID := productEntity.SupplierID

		supplierEntity := &storage.Supplier{}
		if err := storage.Dao.Find(supplierEntity, map[string]interface{}{"id": supplierID}); err != nil {
			fmt.Println("unable to get supplier err = %v", err.Error())
			return nil, err
		}

		var imagesEntity []*storage.Image
		if err := storage.Dao.Find(&imagesEntity, map[string]interface{}{"product_id": productEntity.ID}); err != nil {
			fmt.Println("unable to get images err = %v", err.Error())
			return nil, err
		}
		products = append(products, dto.GetProductDtoFromEntity(productEntity, supplierEntity, imagesEntity))
	}
	return &dto.ListProduct{Products: products}, nil
}

func (impl *inventoryManagementServiceImpl) DeleteProduct(productID int64) (*dto.MessageResponse, error) {
	productEntity := &storage.Product{}
	if err := storage.Dao.Find(productEntity, map[string]interface{}{"id": productID}); err != nil {
		fmt.Println("unable to get product err = %v", err.Error())
		return nil, err
	}

	if err := storage.Dao.Delete(productEntity, "id=?", productID); err != nil {
		fmt.Println("unable to delete product err = %v", err.Error())
		return nil, err
	}
	if err := storage.Dao.Delete(&storage.Image{}, "product_id=?", productID); err != nil {
		fmt.Println("unable to delete product err = %v", err.Error())
		return nil, err
	}
	return &dto.MessageResponse{
		Status:  "success",
		Message: "deleted product successfully",
	}, nil
}
