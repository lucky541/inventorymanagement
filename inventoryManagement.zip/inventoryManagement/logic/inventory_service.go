package logic

import (
	"github.com/lucky541/inventoryManagement/dto"
	"github.com/lucky541/inventoryManagement/server/config"
	"gorm.io/gorm"
)

type InventoryManagementService interface {
	CreateProduct(req *dto.Product) (*dto.Product, error)
	UpdateProduct(req *dto.Product) (*dto.MessageResponse, error)
	GetProductById(productID int64) (*dto.Product, error)
	GetProducts(req *dto.ListProductsFilter) (*dto.ListProduct, error)
	DeleteProduct(productID int64) (*dto.MessageResponse, error)

	CreateSupplier(req *dto.Supplier) (*dto.Supplier, error)
	UpdateSupplier(req *dto.Supplier) (*dto.MessageResponse, error)
	GetSupplierById(productID int64) (*dto.Supplier, error)
	GetSuppliers() (*dto.ListSupplier, error)
}

func NewExampleService(config *config.AppConfig, db *gorm.DB) InventoryManagementService {
	return &inventoryManagementServiceImpl{
		appConfig: config,
		db:        db,
	}
}
