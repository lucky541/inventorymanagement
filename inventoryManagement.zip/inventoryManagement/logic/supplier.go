package logic

import (
	"errors"
	"fmt"
	"github.com/lucky541/inventoryManagement/dto"
	"github.com/lucky541/inventoryManagement/storage"
	"github.com/samber/lo"
	"time"
)

func (impl *inventoryManagementServiceImpl) CreateSupplier(req *dto.Supplier) (*dto.Supplier, error) {
	var supplierEntity *storage.Supplier
	if storage.Dao.Find(&supplierEntity, "phone_number = ? ", req.PhoneNumber); supplierEntity.ID == 0 {
		supplierEntity = &storage.Supplier{
			Name:        req.Name,
			PhoneNumber: req.PhoneNumber,
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
		}

		if err := storage.Dao.Create(supplierEntity); err != nil {
			fmt.Println("unable to create supplier", err.Error())
			return nil, errors.New(fmt.Sprintf("unable to create suppliers err = %v", err.Error()))
		}
		return dto.GetSupplierDtoFromEntity(supplierEntity), nil
	}
	return nil, errors.New("supplier already exists")
}

func (impl *inventoryManagementServiceImpl) UpdateSupplier(req *dto.Supplier) (*dto.MessageResponse, error) {
	supplierEntity := &storage.Supplier{}
	if err := storage.Dao.Find(supplierEntity, map[string]interface{}{"id": req.ID}); err != nil {
		fmt.Println("unable to get supplier err = %v", err.Error())
		return nil, errors.New(fmt.Sprintf("unable to get suppliers err = %v", err.Error()))
	}
	newSupplier := supplierEntity
	newSupplier = &storage.Supplier{
		ID:          supplierEntity.ID,
		Name:        lo.Ternary(req.Name != "", req.Name, supplierEntity.Name),
		PhoneNumber: lo.Ternary(req.PhoneNumber != "", req.PhoneNumber, supplierEntity.PhoneNumber),
		UpdatedAt:   time.Now(),
	}
	if err := storage.Dao.Update(supplierEntity, newSupplier); err != nil {
		fmt.Println("unable to update supplier err = %v", err.Error())
		return nil, errors.New(fmt.Sprintf("unable to update suppliers err = %v", err.Error()))
	}
	return &dto.MessageResponse{
		Status:  "success",
		Message: "updated supplier successfully",
	}, nil
}

func (impl *inventoryManagementServiceImpl) GetSupplierById(supplierId int64) (*dto.Supplier, error) {
	supplierEntity := &storage.Supplier{}
	if storage.Dao.Find(supplierEntity, map[string]interface{}{"id": supplierId}); supplierEntity.ID == 0 {
		fmt.Println("unable to get supplier")
		return nil, errors.New(fmt.Sprintf("unable to get supplier "))
	}
	return dto.GetSupplierDtoFromEntity(supplierEntity), nil
}

func (impl *inventoryManagementServiceImpl) GetSuppliers() (*dto.ListSupplier, error) {
	suppliers := []*dto.Supplier{}
	var supplierEntities []*storage.Supplier
	if err := storage.Dao.Find(&supplierEntities); err != nil {
		fmt.Println("unable to get supplier err = %v", err.Error())
		return nil, errors.New(fmt.Sprintf("unable to get suppliers err = %v", err.Error()))
	}

	for _, supplier := range supplierEntities {
		suppliers = append(suppliers, dto.GetSupplierDtoFromEntity(supplier))
	}

	return &dto.ListSupplier{Supplier: suppliers}, nil
}
