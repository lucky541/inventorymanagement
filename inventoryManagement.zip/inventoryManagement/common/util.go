package common

import (
	"os"
)

// ReadFile reads a file from the given path and returns its content as []byte
func ReadFile(filePath string) ([]byte, error) {
	dir, _ := os.Getwd()
	content, err := os.ReadFile(dir + filePath)
	if err != nil {
		return nil, err
	}
	return content, nil
}
