package common

import "github.com/lucky541/inventoryManagement/dto"

const (
	BadRequest     = "bad_request"
	InternalServer = "internalServer"
)

var errorMap map[string]*dto.MessageResponse

func init() {

	errorMap = map[string]*dto.MessageResponse{
		BadRequest: {
			Status:  BadRequest,
			Message: "invalid request body",
		},
		InternalServer: {
			Status:  BadRequest,
			Message: "invalid request body",
		},
	}
}

func GetErrorCode(code string) *dto.MessageResponse {
	return errorMap[code]
}
