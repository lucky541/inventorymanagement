-- Create the inventory_db database
CREATE DATABASE IF NOT EXISTS inventory;

-- Switch to the inventory_db database
USE inventory;

-- Create the supplier table
CREATE TABLE IF NOT EXISTS suppliers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50),
    phone_number VARCHAR(255), -- unique
    is_deleted BOOLEAN,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_supplier_name (name),
    INDEX idx_supplier_contact_info (contact_info),
    INDEX idx_supplier_created_at (created_at),
    INDEX idx_supplier_updated_at (updated_at)
);

-- Create the product table
CREATE TABLE IF NOT EXISTS products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100), --unique
    supplier_id INT,
    price FLOAT,
    stock_quantity INT,
    is_deleted BOOLEAN,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_product_name (name),
    INDEX idx_product_supplier_id (supplier_id),
    INDEX idx_product_price (price),
    INDEX idx_product_created_at (created_at),
    INDEX idx_product_updated_at (updated_at),
    FOREIGN KEY (supplier_id) REFERENCES supplier(id)
);

-- Create the images table
CREATE TABLE IF NOT EXISTS images (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100),
    data BLOB,
    product_id INT,
    is_deleted BOOLEAN,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_images_created_at (created_at),
    INDEX idx_images_updated_at (updated_at)
);


-- testing