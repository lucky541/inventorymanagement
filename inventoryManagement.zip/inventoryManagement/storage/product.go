package storage

import "time"

type Product struct {
	ID            uint      `gorm:"primarykey"`
	Name          string    `json:"name"`
	SupplierID    uint      `json:"supplierID"`
	Price         float64   `json:"price"`
	StockQuantity int       `json:"stockQuantity"`
	CreatedAt     time.Time `json:"createdAt"`
	UpdatedAt     time.Time `json:"updatedAt"`
}
