package storage

import (
	"errors"
	"fmt"
	"gorm.io/gorm"
	"time"
)

type IDAO interface {
	Create(entity interface{}) error
	Find(entity interface{}, conds ...interface{}) error
	Update(existingEntity interface{}, newEntity interface{}) error
	Delete(model interface{}, conditions ...interface{}) error
}

type DAO struct {
	db *gorm.DB
}

func newDAO(db *gorm.DB) IDAO {
	return &DAO{db: db}
}
func (dao *DAO) Create(entity interface{}) error {
	return dao.db.Create(entity).Error
}

func (dao *DAO) Find(entity interface{}, conds ...interface{}) error {
	return dao.db.Find(entity, conds...).Error
}

func (dao *DAO) Update(existingEntity interface{}, newEntity interface{}) error {
	return dao.db.Model(existingEntity).Updates(newEntity).Error
}

func (dao *DAO) Delete(model interface{}, conditions ...interface{}) error {
	field := "deleted_at"
	scope := dao.db.Model(model)
	if len(conditions) > 0 {
		scope = scope.Where(conditions[0], conditions[1:]...)
	}

	if err := scope.UpdateColumn(field, time.Now()).Error; err != nil {
		fmt.Println(err.Error())
		return errors.New("failed to soft delete record")
	}

	return nil
}
