package storage

import (
	"errors"
	"fmt"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"log"
)

type Config struct {
	HostAndPort string `json:"hostAndPort"`
	Database    string `json:"database"`
	Username    string `json:"username"`
	Password    string `json:"password"`
}

const connectStr = "%s:%s@tcp(%s)/%s?charset=utf8mb4&parseTime=True&loc=Local"

var (
	SupplierDao *SupplierDAO
	Dao         IDAO
)

// InitDB the database
func InitDB(data *Config) (*gorm.DB, error) {
	if data == nil {
		return nil, errors.New("data config is nil/empty")
	}
	var err error

	db, err := gorm.Open(mysql.Open(fmt.Sprintf(connectStr, data.Username,
		data.Password, data.HostAndPort, data.Database)), &gorm.Config{})
	if err != nil {
		log.Fatal("Failed to connect to database:", err)
	}
	fmt.Println("db connection success", db)

	SupplierDao = NewSupplierDAO(db)

	SetupGlobalSettings(db)

	Dao = newDAO(db)

	return db, nil
}

func SetupGlobalSettings(db *gorm.DB) {
	// Set global settings
	db.Callback().Query().Before("gorm:query").Register("excludeDeleted", excludeDeletedCallback)
}

func excludeDeletedCallback(db *gorm.DB) {
	if !db.Statement.Unscoped {
		db = db.Where("deleted_at is null")
	}
}
