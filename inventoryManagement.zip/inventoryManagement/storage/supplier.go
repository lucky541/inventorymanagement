package storage

import (
	"time"
)

type Supplier struct {
	ID          uint   `gorm:"primarykey"`
	Name        string `gorm:"name"`
	PhoneNumber string `gorm:"contact_info"`
	CreatedAt   time.Time
	UpdatedAt   time.Time
}
