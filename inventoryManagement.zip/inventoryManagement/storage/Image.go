package storage

import "time"

type Image struct {
	ID        uint `gorm:"primarykey"`
	Name      string
	Data      []byte
	ProductID uint
	CreatedAt time.Time
	UpdatedAt time.Time
}
