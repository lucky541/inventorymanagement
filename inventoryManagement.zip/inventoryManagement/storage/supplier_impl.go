package storage

import "gorm.io/gorm"

// SupplierDAO represents a Data Access Object for interacting with the Supplier table
type SupplierDAO struct {
	db *gorm.DB
}

// NewSupplierDAO creates a new instance of SupplierDAO with the provided DB connection
func NewSupplierDAO(db *gorm.DB) *SupplierDAO {
	return &SupplierDAO{db: db}
}

// CreateSupplier creates a new Supplier in the database
func (dao *SupplierDAO) CreateSupplier(Supplier *Supplier) error {
	result := dao.db.Create(Supplier)
	return result.Error
}

// GetAllSuppliers retrieves all Suppliers from the database
func (dao *SupplierDAO) GetAllSuppliers() ([]*Supplier, error) {
	var Suppliers []*Supplier
	result := dao.db.Find(&Suppliers)
	return Suppliers, result.Error
}

// GetSupplierByID retrieves all Suppliers from the database
func (dao *SupplierDAO) GetSupplierByID(id string) (*Supplier, error) {
	var Suppliers *Supplier
	condition := map[string]interface{}{
		"id": id,
	}
	result := dao.db.Where(condition).First(&Suppliers)
	return Suppliers, result.Error
}

func (dao *SupplierDAO) NativeQuery() {
	customCondition := func(db *gorm.DB) *gorm.DB {
		return db.Where("name = ?")
	}

	// Query with custom condition
	var Suppliers []Supplier
	dao.db.Scopes(customCondition).Find(&Suppliers)
}
