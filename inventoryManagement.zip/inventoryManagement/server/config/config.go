package config

import (
	"encoding/json"
	"fmt"
	"github.com/lucky541/inventoryManagement/common"
	"github.com/lucky541/inventoryManagement/storage"
)

const filePath = "/resources/config.json"

type AppConfig struct {
	Name string          `json:"name"`
	Port int             `json:"port"`
	Data *storage.Config `json:"data"`
}

func Load() *AppConfig {
	data, err := common.ReadFile(filePath)
	if err != nil {
		panic("unable to load config, exiting")
	}

	appConfig := &AppConfig{}
	if err := json.Unmarshal(data, appConfig); err != nil {
		fmt.Println("parsing error = %v", err.Error())
		return nil
	}

	return appConfig
}
