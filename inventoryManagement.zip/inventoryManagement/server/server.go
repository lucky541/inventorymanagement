package server

import (
	"fmt"
	"github.com/gorilla/mux"
	"github.com/lucky541/inventoryManagement/handler"
	"github.com/lucky541/inventoryManagement/logic"
	"github.com/lucky541/inventoryManagement/server/config"
	"github.com/lucky541/inventoryManagement/storage"
	"net/http"
)

func Server() {
	r := mux.NewRouter()
	appConfig := config.Load()

	// init db
	db, err := storage.InitDB(appConfig.Data)
	if err != nil {
		panic("unable to connect to db, existing")
	}

	// init service
	service := logic.NewExampleService(appConfig, db)

	app := handler.InventoryManagementApp{
		AppConfig:        appConfig,
		DB:               db,
		InventoryService: service,
	}

	app.RegisterRoutes(r)
	r.Use(postMiddleware)

	fmt.Println(fmt.Sprintf("Server Started on port :%v", appConfig.Port))
	http.ListenAndServe(fmt.Sprintf(":%v", appConfig.Port), r)
}

func postMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		next.ServeHTTP(w, r)
	})
}
