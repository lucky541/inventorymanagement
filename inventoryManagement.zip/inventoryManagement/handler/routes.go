package handler

import (
	"encoding/json"
	"fmt"
	"github.com/gorilla/mux"
	"github.com/lucky541/inventoryManagement/common"
	"github.com/lucky541/inventoryManagement/dto"
	"github.com/lucky541/inventoryManagement/logic"
	"github.com/lucky541/inventoryManagement/server/config"
	"gorm.io/gorm"
	"net/http"
	"strconv"
)

type InventoryManagementApp struct {
	AppConfig        *config.AppConfig
	DB               *gorm.DB
	InventoryService logic.InventoryManagementService
}

func (impl *InventoryManagementApp) CreateProduct(w http.ResponseWriter, r *http.Request) {
	req := &dto.Product{}
	if err := decode(r, req); err != nil {
		w.WriteHeader(400)
		json.NewEncoder(w).Encode(err)
		return
	}

	if errors := req.ValidateCreateProductRequest(); len(errors) != 0 {
		w.WriteHeader(400)
		json.NewEncoder(w).Encode(errors)
		return
	}
	response, err := impl.InventoryService.CreateProduct(req)
	if err != nil {
		errorResponse(w, 500, err.Error())
		return
	}
	json.NewEncoder(w).Encode(response)
}

func errorResponse(w http.ResponseWriter, statusCode int, error string) {
	w.WriteHeader(statusCode)
	json.NewEncoder(w).Encode(dto.MessageResponse{
		Status:  "failed",
		Message: error,
	})
}

func (impl *InventoryManagementApp) UpdateProduct(w http.ResponseWriter, r *http.Request) {
	req := &dto.Product{}
	if err := decode(r, req); err != nil {
		w.WriteHeader(400)
		json.NewEncoder(w).Encode(err)
		return
	}
	req.ID, _ = strconv.ParseInt(mux.Vars(r)["id"], 10, 64)
	if errors := req.ValidateUpdateProductRequest(); len(errors) != 0 {
		w.WriteHeader(400)
		json.NewEncoder(w).Encode(errors)
		return
	}
	response, err := impl.InventoryService.UpdateProduct(req)
	if err != nil {
		errorResponse(w, 500, err.Error())
		return
	}
	json.NewEncoder(w).Encode(response)
}

func (impl *InventoryManagementApp) GetAllProducts(w http.ResponseWriter, r *http.Request) {
	req := &dto.ListProductsFilter{}
	if err := decode(r, req); err != nil {
		w.WriteHeader(400)
		json.NewEncoder(w).Encode(err)
		return
	}

	response, _ := impl.InventoryService.GetProducts(req)
	if response == nil {
		response = &dto.ListProduct{}
	}
	json.NewEncoder(w).Encode(response)
}

func (impl *InventoryManagementApp) GetProductByID(w http.ResponseWriter, r *http.Request) {
	id, _ := strconv.ParseInt(mux.Vars(r)["id"], 10, 64)
	response, _ := impl.InventoryService.GetProductById(id)
	json.NewEncoder(w).Encode(response)
}

func (impl *InventoryManagementApp) AdjustProductStock(w http.ResponseWriter, r *http.Request) {
	req := &dto.Product{}
	if err := decode(r, req); err != nil {
		w.WriteHeader(400)
		json.NewEncoder(w).Encode(err)
		return
	}
	req.ID, _ = strconv.ParseInt(mux.Vars(r)["id"], 10, 64)
	if errors := req.ValidateAdjustmentRequest(); len(errors) != 0 {
		w.WriteHeader(400)
		json.NewEncoder(w).Encode(errors)
		return
	}

	response, _ := impl.InventoryService.UpdateProduct(req)
	json.NewEncoder(w).Encode(response)
}

func (impl *InventoryManagementApp) GetDeleteProductByID(w http.ResponseWriter, r *http.Request) {
	id, _ := strconv.ParseInt(mux.Vars(r)["id"], 10, 64)
	response, _ := impl.InventoryService.DeleteProduct(id)
	json.NewEncoder(w).Encode(response)
}

func (impl *InventoryManagementApp) CreateSupplier(w http.ResponseWriter, r *http.Request) {
	req := &dto.Supplier{}
	if err := decode(r, req); err != nil {
		fmt.Println("unable to parse request")
		w.WriteHeader(400)
		json.NewEncoder(w).Encode(err)
		return
	}
	if errors := req.ValidateSupplierRequest(); len(errors) != 0 {
		w.WriteHeader(400)
		json.NewEncoder(w).Encode(errors)
		return
	}

	response, err := impl.InventoryService.CreateSupplier(req)
	if err != nil {
		w.WriteHeader(500)
		json.NewEncoder(w).Encode(dto.MessageResponse{
			Status:  "failed",
			Message: err.Error(),
		})
		return
	}
	json.NewEncoder(w).Encode(response)
}

func (impl *InventoryManagementApp) UpdateSupplier(w http.ResponseWriter, r *http.Request) {
	req := &dto.Supplier{}
	if err := decode(r, req); err != nil {
		w.WriteHeader(400)
		json.NewEncoder(w).Encode(err)
		return
	}
	req.ID, _ = strconv.ParseInt(mux.Vars(r)["id"], 10, 64)
	if errors := req.ValidateSupplierRequest(); len(errors) != 0 {
		w.WriteHeader(400)
		json.NewEncoder(w).Encode(errors)
		return
	}
	response, err := impl.InventoryService.UpdateSupplier(req)
	if err != nil {
		w.WriteHeader(500)
		json.NewEncoder(w).Encode(dto.MessageResponse{
			Status:  "failed",
			Message: err.Error(),
		})
		return
	}
	json.NewEncoder(w).Encode(response)
}

func (impl *InventoryManagementApp) GetAllSuppliers(w http.ResponseWriter, r *http.Request) {
	response, err := impl.InventoryService.GetSuppliers()
	if err != nil {
		w.WriteHeader(500)
		json.NewEncoder(w).Encode(dto.MessageResponse{
			Status:  "failed",
			Message: err.Error(),
		})
		return
	}
	if response == nil {
		response = &dto.ListSupplier{}
	}
	json.NewEncoder(w).Encode(response)
}

func (impl *InventoryManagementApp) GetSupplierByID(w http.ResponseWriter, r *http.Request) {
	id, _ := strconv.ParseInt(mux.Vars(r)["id"], 10, 64)
	response, err := impl.InventoryService.GetSupplierById(id)
	if err != nil {
		w.WriteHeader(500)
		json.NewEncoder(w).Encode(dto.MessageResponse{
			Status:  "failed",
			Message: err.Error(),
		})
		return
	}
	json.NewEncoder(w).Encode(response)
}

func (impl *InventoryManagementApp) RegisterRoutes(r *mux.Router) {
	// supplier routes
	r.HandleFunc("/suppliers", impl.CreateSupplier).Methods(http.MethodPost)
	r.HandleFunc("/suppliers/{id}", impl.UpdateSupplier).Methods(http.MethodPut)
	r.HandleFunc("/suppliers", impl.GetAllSuppliers).Methods(http.MethodGet)
	r.HandleFunc("/suppliers/{id}", impl.GetSupplierByID).Methods(http.MethodGet)

	// product routes
	r.HandleFunc("/products", impl.CreateProduct).Methods(http.MethodPost)
	r.HandleFunc("/products/{id}", impl.UpdateProduct).Methods(http.MethodPut)
	r.HandleFunc("/products/list", impl.GetAllProducts).Methods(http.MethodPost)
	r.HandleFunc("/products/{id}", impl.GetProductByID).Methods(http.MethodGet)
	r.HandleFunc("/products/{id}", impl.GetDeleteProductByID).Methods(http.MethodDelete)
	r.HandleFunc("/products/{id}/stocks", impl.AdjustProductStock).Methods(http.MethodPut)

}

func decode(r *http.Request, dto interface{}) *dto.MessageResponse {
	if err := json.NewDecoder(r.Body).Decode(dto); err != nil {
		return common.GetErrorCode(common.BadRequest)
	}
	return nil
}
