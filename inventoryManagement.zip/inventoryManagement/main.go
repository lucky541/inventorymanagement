package main

import "github.com/lucky541/inventoryManagement/server"

func main() {
	server.Server()
}
